package com.hello.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam; 
import org.springframework.web.bind.annotation.RestController;

import com.hello.model.Hello;
import com.hello.service.HelloService;

@RestController
@RequestMapping("/api")  
public class HelloController { 

	@Autowired
	HelloService helloService;
	
	//@RequestMapping(value = "/hi",method = RequestMethod.GET)
	@GetMapping("/hi")
	public Hello sayHello(@RequestParam("name") String name,@RequestParam("email") String email) {
		
		Hello hello =new Hello();
		hello.setName(name);
		hello.setEmail(email); 
		
		return helloService.sayHello(hello);
	}
	
	@PostMapping("/hipost")
	public Hello sayHelloPost(@Validated @RequestBody Hello hello) {
		
		 	return helloService.sayHello(hello);
	} 
	
	@GetMapping("/getAll")
	public ResponseEntity<List<Hello>> getAll() {
		
		return new ResponseEntity<List<Hello>>(helloService.getAll(),HttpStatus.OK);
	}
	
	
	@GetMapping("/getById")
	public ResponseEntity<Optional<Hello>> getById(@RequestParam("id") Long id) {
		
		return new ResponseEntity<Optional<Hello>>(helloService.getById(id),HttpStatus.OK);
	}
	
	@GetMapping("/bye")
	public ResponseEntity<Map> sayBye() {  	//HttpStatus codes----200-success--- failure -- 404-- 500
	Map<String,String> map=new HashMap<String, String>();//generics--- Map java
	map.put("Message", "Required Email"); 
		return new ResponseEntity<Map>(map,HttpStatus.BAD_REQUEST);
	}
	
	
}
