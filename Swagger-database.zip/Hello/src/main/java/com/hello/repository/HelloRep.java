package com.hello.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hello.model.Hello;

@Repository
public interface HelloRep extends CrudRepository<Hello, Long> {  

}
