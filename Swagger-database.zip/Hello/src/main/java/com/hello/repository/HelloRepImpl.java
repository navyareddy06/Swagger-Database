package com.hello.repository;


public class HelloRepImpl {

	/*
	 * @Override public String sayHello(Hello hello) { // TODO Auto-generated method
	 * stub
	 * 
	 * String str=hello.getName() +"---"+ hello.getEmail();
	 * 
	 * return "Helllooooo !"+str; }
	 */

}
