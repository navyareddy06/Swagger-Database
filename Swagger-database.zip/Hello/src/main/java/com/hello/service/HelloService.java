package com.hello.service;

import java.util.List;
import java.util.Optional;

import com.hello.model.Hello;

public interface HelloService {
	
	public Hello sayHello(Hello hello) ;

	public List<Hello> getAll();

	public Optional<Hello> getById(Long id);

}
