package com.hello.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hello.model.Hello;
import com.hello.repository.HelloRep;

@Service
public class HelloServiceImpl implements HelloService {
	
	@Autowired
	HelloRep helloRep;

	@Override
	public Hello sayHello(Hello hello) {
		// TODO Auto-generated method stub
		return helloRep.save(hello);
	}

	@Override
	public List<Hello> getAll() {
		// TODO Auto-generated method stub
		List<Hello> list=(List<Hello>) helloRep.findAll();
		return list;
	}

	@Override
	public Optional<Hello> getById(Long id) {
		// TODO Auto-generated method stub
		return helloRep.findById(id);
	}

}
